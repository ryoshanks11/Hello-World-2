/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guitest;
import java.awt.Font;
import static java.awt.SystemColor.text;
import javax.swing.*;

/**
 *
 * @author Ryan
 */

public class ResultPanel extends JPanel
{
    ResultPanel(String outputText)
    {
        textOnScreen = outputText;
        setLayout();
    }
    
    private String textOnScreen;
    
    public String getTextOnScreen()
    {
        return textOnScreen;
    }
    
    private void setLayout() {

        JScrollPane jScrollPane1 = new javax.swing.JScrollPane();
        JTextArea textArea = new javax.swing.JTextArea(getTextOnScreen());
        textArea.setFont(new Font("Serif" , Font.ITALIC, 17));
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);

        jScrollPane1.setViewportView(textArea);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 56, Short.MAX_VALUE)
                .addContainerGap())
        );
    }
}